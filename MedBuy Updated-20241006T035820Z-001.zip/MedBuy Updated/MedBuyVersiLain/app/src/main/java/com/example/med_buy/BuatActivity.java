package com.example.med_buy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class BuatActivity extends AppCompatActivity {


}