package com.example.med_buy;

public class DataAlat {

    int id;
    String merk;
    String alat;
    int jumlah;

    public DataAlat(){

    }
}
