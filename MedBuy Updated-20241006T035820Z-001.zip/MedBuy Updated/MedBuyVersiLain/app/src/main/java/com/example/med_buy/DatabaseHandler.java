package com.example.med_buy;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// SQLiteOpenHelper untuk membuat database
public class DatabaseHandler extends SQLiteOpenHelper {

    //Nama Database dan versinya
    protected static final String DB_NAME = "DBAlat";
    private static final int DB_VER = 1;

    public DatabaseHandler(Context context){
        super(context, DB_NAME, null, DB_VER);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Membuat table database dan isinya
        String perintah = "CREATE TABLE Alat" +
                "( id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "merk TEXT, " +
                "alat TEXT," +
                "jumlah INTEGER)";
        sqLiteDatabase.execSQL(perintah);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // Agar table tidak duplicate
        String perintah = "DROP TABLE IF EXISTS Alat";
        sqLiteDatabase.execSQL(perintah);
        onCreate(sqLiteDatabase);
    }
}
