package com.example.med_buy;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.widget.DatePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.Calendar;

public class FragmentTanggal extends DialogFragment implements DatePickerDialog.OnDateSetListener {
    @Override
    public void onDateSet(DatePicker view, int tahun, int bulan, int tanggal) {
        RincianPengirimanDikirimActivity halamanUtama = (RincianPengirimanDikirimActivity) getActivity();
        halamanUtama.ambilTanggal(tahun, bulan, tanggal);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Calendar kalender = Calendar.getInstance();
        int tahun = kalender.get(Calendar.YEAR);
        int bulan = kalender.get(Calendar.MONTH);
        int tanggal = kalender.get(Calendar.DAY_OF_MONTH);

        return new DatePickerDialog(getActivity(), this, tahun, bulan, tanggal);
    }
}

