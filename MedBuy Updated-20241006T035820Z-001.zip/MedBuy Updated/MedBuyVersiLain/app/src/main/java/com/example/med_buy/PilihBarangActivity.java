package com.example.med_buy;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.tabs.TabLayout;

public class PilihBarangActivity extends AppCompatActivity {

    Button bPesann;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pilih_barang);

        bPesann = findViewById(R.id.bPesan);
        bPesann.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Context konteks = view.getRootView().getContext();
                LayoutInflater inflaterku = (LayoutInflater)
                        konteks.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

                View FormView = inflaterku.inflate(R.layout.form_layout, null, false);
                final EditText etNamaAlatt = findViewById(R.id.etNamaAlat);
                final TextView etMerkk = findViewById(R.id.etMerk);
                final TextView etJumlahh = findViewById(R.id.etJumlah);

                new AlertDialog.Builder(konteks)
                        .setView(FormView)
                        .setTitle("Tambah Pesanan")
                        .setPositiveButton("Tambah", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                String merk = etMerkk.getText().toString();
                                String alat = etNamaAlatt.getText().toString();
                                int jumlah = Integer.parseInt(etJumlahh.getText().toString());

                                DataAlat isianAlat = new DataAlat();
                                isianAlat.merk = merk;
                                isianAlat.alat = alat;
                                isianAlat.jumlah = jumlah;

                                boolean sukses = new TabelAlatKontroller(konteks).tambahAlat(isianAlat);

                                if(sukses){
                                    Toast.makeText(konteks, "Berhasil", Toast.LENGTH_SHORT).show();
                                }
                                else{
                                    Toast.makeText(konteks, "Gagal", Toast.LENGTH_SHORT).show();
                                }


                                dialogInterface.cancel();
                            }
                        })
                        .show();
            }
        });
    }
}