package com.example.med_buy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

public class RincianPengirimanDikirimActivity extends AppCompatActivity {

    private static final String LOG_TAG = RincianPengirimanDikirimActivity.class.getSimpleName();
    public static final String EXTRA_MESSAGE = "key untuk extra di intent";
    public static final int TEXT_REQUEST = 1;
    EditText etNamaa;
    TextView tvTanggalSelesai, tvWaktuSelesai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rincianpengirimandikirim);

        etNamaa = findViewById(R.id.etNama);
        tvTanggalSelesai = findViewById(R.id.tvTgl);
        tvWaktuSelesai = findViewById(R.id.tvJam);

    }

    public void PilihTanggal(View view) {
        DialogFragment fTanggal = new FragmentTanggal();
        fTanggal.show(getSupportFragmentManager(), "Pilih Tanggal");
    }

    public void ambilTanggal(int tahun, int bulan, int tanggal) {
        String thn = Integer.toString(tahun);
        String bln = Integer.toString(bulan);
        String tgl = Integer.toString(tanggal);

        TextView tvTanggall = findViewById(R.id.tvTgl);
        tvTanggall.setText(tgl + "/" + bln + "/" + thn);
    }

    public void PilihWaktu(View view) {
        DialogFragment fWaktu = new FragmentWaktu();
        fWaktu.show(getSupportFragmentManager(), "Pilih Waktu");
    }

    public void ambilWaktu(int jam, int menit) {
        String jm = Integer.toString(jam);
        String mn = Integer.toString(menit);

        TextView tvWaktuu = findViewById(R.id.tvJam);
        tvWaktuu.setText(jm + ":" + mn);
    }

    public void PengirimanSelesai(View view) {
        String nama = etNamaa.getText().toString();
        String tanggalselesai = tvTanggalSelesai.getText().toString();
        String waktuselesai = tvWaktuSelesai.getText().toString();

        Intent intent = new Intent(RincianPengirimanDikirimActivity.this, RincianPengirimanSelesaiActivity.class);
        intent.putExtra("keynama", nama);
        intent.putExtra("keytanggal", tanggalselesai);
        intent.putExtra("keywaktu", waktuselesai);
        startActivity(intent);
    }
}