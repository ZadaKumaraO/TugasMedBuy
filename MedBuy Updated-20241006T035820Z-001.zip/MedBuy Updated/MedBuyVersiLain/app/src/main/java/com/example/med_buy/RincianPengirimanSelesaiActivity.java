package com.example.med_buy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RincianPengirimanSelesaiActivity extends AppCompatActivity {

    TextView Penerima, NoPesanan, WaktuSelesai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rincian_pengiriman_selesai);

        Penerima = findViewById(R.id.tvNamaOrang);
        NoPesanan = findViewById(R.id.tvKode);
        WaktuSelesai = findViewById(R.id.tvWaktuSelesai);

        Intent intent = getIntent();
        String nama = getIntent().getStringExtra("keynama");
        String tanggalselesai = getIntent().getStringExtra("keytanggal");
        String waktuselesai = getIntent().getStringExtra("keywaktu");
        Penerima.setText(nama);
        WaktuSelesai.setText(tanggalselesai +" "+ waktuselesai);
    }

    public void DetailPesanan(View view) {
    }
}