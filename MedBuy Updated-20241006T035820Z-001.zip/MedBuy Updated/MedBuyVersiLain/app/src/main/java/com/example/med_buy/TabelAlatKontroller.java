package com.example.med_buy;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class TabelAlatKontroller extends DatabaseHandler {

    public TabelAlatKontroller(Context context) {
        super(context);
    }

    public boolean tambahAlat (DataAlat dataAlat){
        // Menambah Data
        ContentValues nilai = new ContentValues();
        nilai.put("merk", dataAlat.merk);
        nilai.put("alat", dataAlat.alat);
        nilai.put("jumlah", dataAlat.jumlah);

        SQLiteDatabase db = this.getWritableDatabase();
        boolean sukses = db.insert("Alat", null, nilai) > 0;
        db.close();

        return sukses;
    }

}
